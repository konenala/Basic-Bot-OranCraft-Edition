const os = require('os')
const fs = require('fs')
const crypto = require('crypto')
const path = require('path')
const readline = require('readline')
const mineflayer = require('mineflayer')
const tokens = require('prismarine-tokens-fixed')
const ResourcePackHandler = require('./src/utils/ResourcePackHandler')

require('events').EventEmitter.defaultMaxListeners = 0

// --- Path and Config Setup ---
// When packaged with pkg, __dirname points to the snapshot filesystem.
// We need to use process.execPath to find the directory of the actual executable.
const executableDir = path.dirname(process.execPath)

console.log('--- [DEBUG] Path Information ---')
console.log(`Executable Directory (executableDir): ${executableDir}`)
console.log(`Current Working Directory (process.cwd()): ${process.cwd()}`)
console.log('---------------------------------')

// --- Runtime Configuration Loading ---
// This logic determines the config file path at runtime, preventing pkg from bundling it.
// Priority: 1. CLI argument, 2. Environment variable, 3. Default file next to executable.
function getConfigPath() {
  // 1. Check for --config=<path> argument
  const arg = process.argv.find(a => a.startsWith('--config='))
  if (arg) {
    return path.resolve(arg.split('=')[1])
  }

  // 2. Check for BOT_CONFIG_PATH environment variable
  if (process.env.BOT_CONFIG_PATH) {
    return path.resolve(process.env.BOT_CONFIG_PATH)
  }

  // 3. Default to config.json next to the executable
  // We still use string concatenation as a final safeguard against static analysis.
  return path.join(executableDir, ['conf', 'ig', '.json'].join(''))
}

const configPath = getConfigPath()
let config
try {
  console.log(`[INFO] Attempting to load configuration from: ${configPath}`)
  if (!fs.existsSync(configPath)) {
    throw new Error(`Configuration file 'config.json' not found at: ${configPath}`)
  }
  const configFileContent = fs.readFileSync(configPath, 'utf8')
  config = JSON.parse(configFileContent)
} catch (error) {
  console.error(`[FATAL] Failed to read or parse config file: ${error.message}`)
  process.exit(1) // Exit if config is missing or invalid
}

const TOKEN_ENC_PATH = path.join(executableDir, 'bot_tokens.enc')
const TOKEN_TMP_PATH = path.join(os.tmpdir(), `bot_tokens_${path.basename(executableDir)}.tmp.json`)

console.log('--- [DEBUG] Token File Paths ---')
console.log(`Encrypted Token Path: ${TOKEN_ENC_PATH}`)
console.log(`Temporary Token Path: ${TOKEN_TMP_PATH}`)
console.log('----------------------------------')

// --- Pre-run Sanity Check ---
if (fs.existsSync(TOKEN_TMP_PATH)) {
  console.warn(`[WARN] A temporary token file from a previous session was found at: ${TOKEN_TMP_PATH}. This may cause login issues. Deleting it now.`)
  try { fs.unlinkSync(TOKEN_TMP_PATH) } catch (e) { console.error(`[ERROR] Failed to delete stale temporary token file: ${e.message}`) }
}

// --- Global Error Handling & Variables ---
process.on('uncaughtException', (err) => {
  console.log('UncoughtError: ' + (err && err.stack ? err.stack : err))
})
let deathCount = 0
let dailyRewardTimer = null
let moneyTransferTimer = null
let lastClaimDate = null
const HEART_SYMBOL = '❤'

// --- Helper Functions ---
function getCleanWhitelist() {
  return (config.whitelist || []).map(cleanPlayerName)
}

function cleanPlayerName(username) {
  return username.replace(/\s*\(.+?\)\s*/, '').trim()
}

function buildBotOptions() {
  const opts = {
    host: config.ip,
    port: config.port,
    username: config.username,
    auth: config.auth,
    version: config.version,
    tokensLocation: TOKEN_TMP_PATH,
    tokens: tokens
  }
  return opts
}

// --- Main Bot Logic ---
async function startBot() {
  try {
    await prepareDecryptedTokensIfNeeded()
    const opts = buildBotOptions()

    await tokens.use(opts, async (err, opts) => {
      if (err) {
        console.error('[LOGIN_ERROR]', err)
        throw err
      }

      const bot = mineflayer.createBot(opts)

      // 初始化並立即啟用資源包處理器（1.20.2+ configuration 階段需要）
      const resourcePackHandler = new ResourcePackHandler(bot, {
        autoAccept: true,
        logPackets: true
      })
      resourcePackHandler.enable()
      console.log('[ResourcePack] 資源包自動接受已啟用')

      // ----- Chat bridge (stdin -> game) -----
      const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false })
      rl.on('line', (line) => {
        try { if (line && line.length) bot.chat(line) } catch (e) { console.error('[RL_CHAT_ERROR]', e) }
      })

      // ----- On spawn -----
      bot.once('spawn', () => {
        console.log('bot已成功啟動!')
        console.log('whitelist:', getCleanWhitelist())
        bot.loadPlugin(require('mineflayer-collectblock').plugin)
        bot.chatAddPattern(/^\[傳送\]\s*(.+?)\s*請求傳送到你這裡（請注意安全）。?$/, 'tpa_to_me', 'TPA請求')
        bot.chatAddPattern(/^\[傳送\]\s*(.+?)\s*請求你傳送到他那裡（請注意安全）。?$/, 'tpa_from_me', 'TPA請求')
        scheduleDailyRewards(bot)

        // --- Hourly Money Transfer Task ---
        const targetPlayer = config.moneyTransferTarget
        if (targetPlayer) {
          // Safety Check: Do not enable payments if the bot is the target.
          if (bot.username.toLowerCase() === targetPlayer.toLowerCase()) {
            console.log(`[PAY] Bot's username (${bot.username}) is the same as the payment target. Auto-payment feature is disabled for safety.`)
            return
          }

          if (moneyTransferTimer) clearInterval(moneyTransferTimer) // 清除舊的計時器以防重連時重複
          console.log(`[PAY] 每小時自動轉帳功能已啟用，目標玩家: ${targetPlayer}。`)
          // 首次啟動時先執行一次
          transferMoneyTask(bot)
          // 設定每小時執行一次 (1小時 = 3600000 毫秒)
          moneyTransferTimer = setInterval(() => transferMoneyTask(bot), 3600000)
        } else {
          console.log('[PAY] 未在 config.json 中設定 moneyTransferTarget，自動轉帳功能已停用。')
        }
      })

      // ----- TPA handling -----
      bot.on('tpa_to_me', (player) => {
        const cleanedPlayer = cleanPlayerName(player)
        if (getCleanWhitelist().includes(cleanedPlayer)) {
          bot.chat(`/tpyes ${cleanedPlayer}`)
          console.log(`已接受來自 ${cleanedPlayer} 的TPA請求`)
        } else {
          bot.chat(`/tpno ${cleanedPlayer}`)
          console.log(`已拒絕來自 ${cleanedPlayer} 的TPA請求 (不在白名單)`)
        }
      })

      bot.on('tpa_from_me', (player) => {
        const cleanedPlayer = cleanPlayerName(player)
        if (getCleanWhitelist().includes(cleanedPlayer)) {
          bot.chat(`/tpyes ${cleanedPlayer}`)
          console.log(`已接受來自 ${cleanedPlayer} 的TPA請求`)
        } else {
          bot.chat(`/tpno ${cleanedPlayer}`)
          console.log(`已拒絕來自 ${cleanedPlayer} 的TPA請求 (不在白名單)`)
        }
      })

      // ----- Message handling (commands) -----
      bot.on('message', (jsonMsg) => {
        const text = jsonMsg.toString().trim()
        if (!text) return

        try { if (!text.includes(HEART_SYMBOL)) console.log(text) } catch (e) { console.error('[MSG_LOG_ERROR]', e) }

        // --- New Reward Claim Trigger ---
        if (text.includes('[獎勵] 看起來您還沒有領取每日獎勵')) {
          console.log('[REWARD] Detected reminder message, attempting to claim now.');
          claimDailyRewards(bot);
        }
        // --- End New Trigger ---

        const directMsgMatch = text.match(/^\[(.+?)\s*->\s*我\]\s*(.+)$/)
        if (directMsgMatch) {
          const player = cleanPlayerName(directMsgMatch[1])
          const message = directMsgMatch[2].trim()
          if (getCleanWhitelist().includes(player)) {
            const command = message.split(' ')[0]
            if (command === 'dropall') dropAll(bot)
            if (command === 'job') autoJob(bot)
            if (command === 'gorpg') toRpg(bot)
          }
        }
      })

      // ----- Death handling -----
      bot.on('death', async () => {
        await bot.waitForTicks(10)
        deathCount++
        console.log(`已死亡: ${deathCount} 次，且已自動/back返回`)
        try { bot.chat('/back') } catch (e) { console.error('Failed to send /back command after death:', e) }
      })

      // ----- Kick/disconnect debug -----
      bot.on('kicked', (reason) => {
        console.log('被伺服器踢出:', reason)
      })

      bot.on('error', (err) => {
        console.log('發生錯誤:', err)
      })

      // ----- Auto-reconnect -----
      bot.on('end', (reason) => {
        console.log(`連線已中斷: ${reason}, 10秒後將重新連線...`)
        rl.close()
        clearTimeout(dailyRewardTimer)
        clearInterval(moneyTransferTimer)
        setTimeout(startBot, 10000)
      })
    })
  } finally {
    await finalizeEncryptTokensIfNeeded()
  }
}

// --- Actions ---
async function dropAll(bot) {
  console.log('正在丟棄所有物品...')
  for (const item of bot.inventory.items()) {
    try {
      await bot.tossStack(item)
    } catch (e) {
      // ignore errors
    }
  }
  console.log('所有物品已丟棄完畢')
}

async function autoJob(bot) {
  console.log('正在自動選擇職業...')
  try {
    bot.chat('/job')
    const menu = await bot.waitForWindow()
    await bot.clickWindow(19, 0, 0) // 點擊礦工
    await bot.waitForTicks(20)
    await bot.clickWindow(40, 0, 0) // 點擊確認
    bot.closeWindow(menu)
    console.log('職業選擇完畢')
  } catch (e) {
    console.error('自動選擇職業失敗:', e)
  }
}

async function toRpg(bot) {
  console.log('正在前往RPG分流...')
  try {
    bot.chat('/rpg')
    const menu = await bot.waitForWindow()
    await bot.clickWindow(9, 0, 0) // 點擊RPG-1
    await bot.waitForTicks(20)
    await bot.clickWindow(24, 0, 0) // 點擊確認
    bot.closeWindow(menu)
    console.log('已進入RPG分流')
  } catch (e) {
    console.error('前往RPG分流失敗:', e)
  }
}

async function transferMoneyTask(bot) {
  const targetPlayer = config.moneyTransferTarget
  try {
    console.log('[PAY] 執行每小時轉帳任務...')
    const amount = await getMoney(bot)

    if (amount !== null && amount > 0) {
      console.log(`[PAY] 查詢到餘額: ${amount}。正在支付給 ${targetPlayer}...`)
      bot.chat(`/pay ${targetPlayer} ${amount}`)
    } else {
      console.log('[PAY] 餘額為0或查詢失敗，本次不執行轉帳。')
    }
  } catch (err) {
    console.error('[PAY] 轉帳任務發生錯誤:', err.message)
  }
}

function getMoney(bot) {
  console.log('[MONEY] 正在查詢餘額...')
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      bot.removeListener('message', listener)
      reject(new Error('查詢餘額超時，伺服器沒有回應。'))
    }, 10000) // 10秒超時

    const listener = (jsonMsg) => {
      const message = jsonMsg.toString().trim()
      if (!message) return

      // [偵錯用] 將收到的每一條訊息都印出來，方便我們看到原始資料
      console.log(`[MONEY_DEBUG] Received message: "${message}"`)

      // 最終修正版正規表示式：
      // 1. 使用 [\s:：$]* 避免貪婪匹配問題
      // 2. 使用 ([\d,]+\.?\d*) 來同時支援整數和小數
      const moneyRegex = /(?:餘額|金錢|您目前擁有|money|balance)[\s:：$]*([\d,]+\.?\d*)/i
      const match = message.match(moneyRegex)

      if (match && match[1]) {
        clearTimeout(timeout)
        bot.removeListener('message', listener)
        // 使用 parseFloat 來處理小數，並在轉換前移除所有逗號
        const amount = parseFloat(match[1].replace(/,/g, ''))
        resolve(amount)
      }
    }

    bot.on('message', listener)
    bot.chat('/money')
  })
}

// --- Daily Rewards ---
function scheduleDailyRewards(bot) {
  if (dailyRewardTimer) clearTimeout(dailyRewardTimer)

  const now = new Date()
  const tomorrow = new Date(now)
  tomorrow.setDate(now.getDate() + 1)
  tomorrow.setHours(0, 1, 0, 0) // 設置為隔天 00:01:00

  const msUntilTomorrow = tomorrow.getTime() - now.getTime()
  console.log(`[REWARD] next schedule in ${Math.round(msUntilTomorrow / 1000)} s`)

  dailyRewardTimer = setTimeout(() => {
    claimDailyRewards(bot)
    scheduleDailyRewards(bot) // Schedule for the next day
  }, msUntilTomorrow)

  // Claim now if it hasn't been claimed today
  claimDailyRewards(bot)
}

function claimDailyRewards(bot) {
  const today = new Date().toISOString().slice(0, 10)
  if (lastClaimDate !== today) {
    console.log(`[REWARD] claimed for ${today}`)
    lastClaimDate = today
    try {
      bot.chat('/rewards claim')
    } catch (e) {
      console.error('Failed to claim daily rewards:', e)
    }
  }
}

// --- Token Encryption/Decryption ---
function getTokenPassphrase() {
  return process.env.TOKEN_KEY || (config.tokenEncryption && config.tokenEncryption.passphrase)
}

function deriveKey(passphrase, salt) {
  return crypto.scryptSync(passphrase, salt, 32, { N: 16384, r: 8, p: 1 })
}

async function encryptToFile(data, filePath, passphrase) {
  const salt = crypto.randomBytes(16)
  const key = deriveKey(passphrase, salt)
  const iv = crypto.randomBytes(12)
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv)

  const encrypted = Buffer.concat([cipher.update(data, 'utf8'), cipher.final()])
  const authTag = cipher.getAuthTag()

  const fileContent = Buffer.concat([Buffer.from('ENC1'), salt, iv, authTag, encrypted])
  fs.writeFileSync(filePath, fileContent)
}

async function decryptFromFile(filePath, passphrase) {
  const fileContent = fs.readFileSync(filePath)
  const salt = fileContent.slice(4, 20)
  const iv = fileContent.slice(20, 32)
  const authTag = fileContent.slice(32, 48)
  const encrypted = fileContent.slice(48)

  const key = deriveKey(passphrase, salt)
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv)
  decipher.setAuthTag(authTag)

  return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8')
}

async function prepareDecryptedTokensIfNeeded() {
  const passphrase = getTokenPassphrase()
  if (passphrase && fs.existsSync(TOKEN_ENC_PATH)) {
    console.log('[TOKEN] Found encrypted token file, decrypting...')
    const decryptedData = await decryptFromFile(TOKEN_ENC_PATH, passphrase)
    fs.writeFileSync(TOKEN_TMP_PATH, decryptedData)
  }
}

async function finalizeEncryptTokensIfNeeded() {
  const passphrase = getTokenPassphrase()
  if (passphrase && fs.existsSync(TOKEN_TMP_PATH)) {
    console.log('[TOKEN] Encrypting session tokens for future use...')
    const dataToEncrypt = fs.readFileSync(TOKEN_TMP_PATH, 'utf8')
    await encryptToFile(dataToEncrypt, TOKEN_ENC_PATH, passphrase)
  }
  // Securely delete the temporary file
  if (fs.existsSync(TOKEN_TMP_PATH)) {
    try {
      fs.unlinkSync(TOKEN_TMP_PATH)
    } catch (e) {
      console.error('Failed to delete temporary token file:', e)
    }
  }
}

// --- Graceful Shutdown ---
function cleanup() {
  if (fs.existsSync(TOKEN_TMP_PATH)) {
    console.log('Cleaning up temporary files...')
    try {
      fs.unlinkSync(TOKEN_TMP_PATH)
    } catch (e) {
      // ignore
    }
  }
}
process.on('exit', cleanup)
process.on('SIGINT', () => process.exit()) // ctrl-c
process.on('SIGTERM', () => process.exit()) // kill

// --- Start the bot ---
startBot()